import CocoaLumberjackSwift
import Foundation

enum DeviceMatrixService {
    enum ApplyError: LocalizedError {
        case missingPayload

        var errorDescription: String? {
            switch self {
            case .missingPayload:
                return "设备信息载荷缺失"
            }
        }
    }

    static func apply(to app: App) throws {
        guard let payload = Bundle.main.url(forResource: "DeviceMatrixPayload", withExtension: "dylib") else {
            throw ApplyError.missingPayload
        }

        do {
            let injector = try InjectorV3(app.url)
            try injector.inject([payload], shouldPersist: true)
            DDLogInfo("DeviceMatrix applied to \(app.bid)", ddlog: InjectorV3.main.logger)
        } catch {
            DDLogError("DeviceMatrix failed for \(app.bid): \(error)", ddlog: InjectorV3.main.logger)
            throw error
        }
    }
}
