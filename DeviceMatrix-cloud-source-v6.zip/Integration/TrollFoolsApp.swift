import SwiftUI

@main
struct TrollFoolsApp: SwiftUI.App {
    init() {
        try? FileManager.default.removeItem(at: InjectorV3.temporaryRoot)
    }

    var body: some Scene {
        WindowGroup {
            DeviceMatrixOneClickView()
                .environmentObject(AppListModel())
        }
    }
}
