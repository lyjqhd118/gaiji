import SwiftUI

struct DeviceMatrixOneClickView: View {
    @EnvironmentObject private var appList: AppListModel
    @State private var query = ""
    @State private var busy = Set<String>()
    @State private var message = "选择目标应用后点按“一键改机”"

    private var allApps: [App] {
        appList.activeScopeApps.values.flatMap { $0 }
    }

    private var visibleApps: [App] {
        guard !query.isEmpty else { return allApps }
        return allApps.filter {
            $0.name.localizedCaseInsensitiveContains(query) ||
                $0.bid.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("一键改机")
                        .font(.title2.bold())
                    Text("只对你选择的应用进程生效，改机配置由载荷按 Bundle ID 稳定生成")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                    Text(message)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)
                .padding(.top, 8)
                .padding(.bottom, 6)

                if visibleApps.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "app.dashed")
                            .font(.largeTitle)
                            .foregroundColor(.secondary)
                        Text("没有可用的目标应用")
                            .foregroundColor(.secondary)
                        Button("刷新应用列表") { refresh() }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(visibleApps, id: \.bid) { app in
                        HStack(spacing: 10) {
                            Image(uiImage: app.alternateIcon ?? app.icon ?? UIImage())
                                .resizable()
                                .frame(width: 40, height: 40)
                                .clipShape(RoundedRectangle(cornerRadius: 9))

                            VStack(alignment: .leading, spacing: 3) {
                                Text(app.name)
                                    .font(.headline)
                                    .lineLimit(1)
                                Text(app.bid)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                    .lineLimit(1)
                                if app.isInjected || app.hasPersistedAssets {
                                    Text("已应用")
                                        .font(.caption2)
                                        .foregroundColor(.green)
                                }
                            }

                            Spacer(minLength: 4)

                            Button {
                                apply(to: app)
                            } label: {
                                Text(busy.contains(app.bid) ? "处理中" : "一键改机")
                                    .font(.caption.bold())
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(busy.contains(app.bid))
                        }
                        .padding(.vertical, 5)
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("DeviceMatrix")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("刷新") { refresh() }
                }
            }
        }
        .searchable(text: $query, prompt: "搜索应用或 Bundle ID")
        .onAppear { refresh() }
    }

    private func refresh() {
        appList.reload()
        message = "已刷新 (allApps.count) 个可用应用"
    }

    private func apply(to app: App) {
        busy.insert(app.bid)
        message = "正在为 (app.name) 应用设备信息…"
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try DeviceMatrixService.apply(to: app)
                DispatchQueue.main.async {
                    app.reload()
                    busy.remove(app.bid)
                    message = "(app.name) 已应用，完全退出后重新打开目标应用"
                }
            } catch {
                DispatchQueue.main.async {
                    busy.remove(app.bid)
                    message = "应用失败：\(error.localizedDescription)"
                }
            }
        }
    }
}
