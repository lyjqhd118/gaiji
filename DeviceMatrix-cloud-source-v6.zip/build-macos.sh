#!/bin/sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
BUILD="$ROOT/build"
DIST="$ROOT/dist"

command -v xcodebuild >/dev/null 2>&1 || { echo "xcodebuild is required" >&2; exit 2; }
command -v xcodegen >/dev/null 2>&1 || { echo "xcodegen is required" >&2; exit 2; }
command -v ldid >/dev/null 2>&1 || { echo "ldid is required for TrollStore signing" >&2; exit 2; }

rm -rf "$BUILD" "$DIST"
mkdir -p "$BUILD/payload" "$BUILD/app" "$DIST"
xcodegen generate --spec "$ROOT/project.yml"

xcodebuild -project "$ROOT/DeviceMatrix.xcodeproj" -scheme DeviceMatrixPayload \
  -configuration Release -sdk iphoneos -derivedDataPath "$BUILD/derived-payload" \
  CODE_SIGNING_ALLOWED=NO build
xcodebuild -project "$ROOT/DeviceMatrix.xcodeproj" -scheme DeviceMatrix \
  -configuration Release -sdk iphoneos -derivedDataPath "$BUILD/derived-app" \
  CODE_SIGN_IDENTITY=- CODE_SIGNING_ALLOWED=YES build

PAYLOAD=$(find "$BUILD/derived-payload/Build/Products" -name 'DeviceMatrixPayload.dylib' -type f | head -n 1)
APP=$(find "$BUILD/derived-app/Build/Products" -path '*/Release-iphoneos/DeviceMatrix.app' -type d | head -n 1)
test -n "$PAYLOAD" && test -n "$APP"
cp "$PAYLOAD" "$APP/DeviceMatrixPayload.dylib"

ldid -S "$PAYLOAD"
ldid -S "$APP/DeviceMatrixPayload.dylib"
ldid -S "$APP/DeviceMatrix"

mkdir -p "$DIST/Payload"
cp -R "$APP" "$DIST/Payload/"
(cd "$DIST" && /usr/bin/zip -qry DeviceMatrix.ipa Payload)
echo "[OK] $DIST/DeviceMatrix.ipa"

