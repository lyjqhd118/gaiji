from __future__ import annotations

import argparse
import re
import shutil
import uuid
from pathlib import Path


def new_id() -> str:
    return uuid.uuid4().hex[:24].upper()


def insert_once(text: str, marker: str, addition: str) -> str:
    if addition.strip() in text:
        return text
    index = text.find(marker)
    if index < 0:
        raise RuntimeError(f"marker not found: {marker}")
    return text[:index] + addition + text[index:]


def insert_after_once(text: str, marker: str, addition: str) -> str:
    if addition.strip() in text:
        return text
    index = text.find(marker)
    if index < 0:
        raise RuntimeError(f"marker not found: {marker}")
    end = index + len(marker)
    return text[:end] + addition + text[end:]


def patch_project(root: Path, payload: Path, service: Path) -> None:
    app_dir = root / "TrollFools"
    project = root / "TrollFools.xcodeproj" / "project.pbxproj"
    if not project.is_file():
        raise RuntimeError(f"missing project: {project}")

    view = Path(__file__).resolve().parent / "Integration" / "DeviceMatrixOneClickView.swift"
    entry = Path(__file__).resolve().parent / "Integration" / "TrollFoolsApp.swift"
    if not view.is_file() or not entry.is_file():
        raise RuntimeError("missing DeviceMatrix one-click UI sources")
    shutil.copy2(service, app_dir / "DeviceMatrixService.swift")
    shutil.copy2(view, app_dir / "DeviceMatrixOneClickView.swift")
    shutil.copy2(entry, app_dir / "TrollFoolsApp.swift")
    shutil.copy2(payload, app_dir / "DeviceMatrixPayload.dylib")

    cell = app_dir / "AppListCell.swift"
    cell_text = cell.read_text(encoding="utf-8")
    anchor = '        Button {\n            openInFilza()\n'
    button = (
        '        Button {\n'
        '            try? DeviceMatrixService.apply(to: app)\n'
        '        } label: {\n'
        '            Label("Apply DeviceMatrix", systemImage: "wand.and.stars")\n'
        '        }\n\n'
    )
    cell_text = insert_once(cell_text, anchor, button)
    cell.write_text(cell_text, encoding="utf-8")

    text = project.read_text(encoding="utf-8")
    text = text.replace("INFOPLIST_KEY_CFBundleDisplayName = TrollFools;", "INFOPLIST_KEY_CFBundleDisplayName = DeviceMatrix;")
    info = app_dir / "Info.plist"
    if info.is_file():
        info_text = info.read_text(encoding="utf-8")
        info_text = info_text.replace("<string>TrollFools</string>", "<string>DeviceMatrix</string>", 1)
        info.write_text(info_text, encoding="utf-8")
    if ("DeviceMatrixService.swift in Sources" in text and
            "DeviceMatrixOneClickView.swift in Sources" in text and
            "DeviceMatrixPayload.dylib in Resources" in text):
        print(f"[OK] already patched {root}")
        return
    source_ref = new_id()
    source_build = new_id()
    view_ref = new_id()
    view_build = new_id()
    payload_ref = new_id()
    payload_build = new_id()

    text = insert_once(
        text,
        "/* End PBXBuildFile section */",
        f"\t\t{source_build} /* DeviceMatrixService.swift in Sources */ = {{isa = PBXBuildFile; fileRef = {source_ref} /* DeviceMatrixService.swift */; }};\n"
        f"\t\t{view_build} /* DeviceMatrixOneClickView.swift in Sources */ = {{isa = PBXBuildFile; fileRef = {view_ref} /* DeviceMatrixOneClickView.swift */; }};\n"
        f"\t\t{payload_build} /* DeviceMatrixPayload.dylib in Resources */ = {{isa = PBXBuildFile; fileRef = {payload_ref} /* DeviceMatrixPayload.dylib */; }};\n",
    )
    text = insert_once(
        text,
        "/* End PBXFileReference section */",
        f"\t\t{source_ref} /* DeviceMatrixService.swift */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = DeviceMatrixService.swift; sourceTree = \"<group>\"; }};\n"
        f"\t\t{view_ref} /* DeviceMatrixOneClickView.swift */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = DeviceMatrixOneClickView.swift; sourceTree = \"<group>\"; }};\n"
        f"\t\t{payload_ref} /* DeviceMatrixPayload.dylib */ = {{isa = PBXFileReference; lastKnownFileType = compiled.mach-o.dylib; path = DeviceMatrixPayload.dylib; sourceTree = \"<group>\"; }};\n",
    )

    app_sources = "CCF470522C4A4649008D8197 /* Sources */ = {"
    source_block_start = text.find(app_sources)
    source_block_end = text.find("/* End PBXSourcesBuildPhase section */", source_block_start)
    source_block = text[source_block_start:source_block_end]
    source_block = insert_after_once(
        source_block,
        "\t\t\tfiles = (\n",
        f"\t\t\t\t{source_build} /* DeviceMatrixService.swift in Sources */,\n",
    )
    source_block = insert_after_once(
        source_block,
        "\t\t\tfiles = (\n",
        f"\t\t\t\t{view_build} /* DeviceMatrixOneClickView.swift in Sources */,\n",
    )
    text = text[:source_block_start] + source_block + text[source_block_end:]

    resource_phase = "CCF470542C4A4649008D8197 /* Resources */ = {"
    resource_block_start = text.find(resource_phase)
    resource_block_end = text.find("/* End PBXResourcesBuildPhase section */", resource_block_start)
    resource_block = text[resource_block_start:resource_block_end]
    resource_block = insert_after_once(
        resource_block,
        "\t\t\tfiles = (\n",
        f"\t\t\t\t{payload_build} /* DeviceMatrixPayload.dylib in Resources */,\n",
    )
    text = text[:resource_block_start] + resource_block + text[resource_block_end:]

    app_group = "CCF470582C4A4649008D8197 /* TrollFools */ = {"
    group_start = text.find(app_group)
    group_end = text.find("/* End PBXGroup section */", group_start)
    group_block = text[group_start:group_end]
    group_block = insert_after_once(
        group_block,
        "\t\t\tchildren = (\n",
        f"\t\t\t\t{source_ref} /* DeviceMatrixService.swift */,\n",
    )
    group_block = insert_after_once(
        group_block,
        "\t\t\tchildren = (\n",
        f"\t\t\t\t{view_ref} /* DeviceMatrixOneClickView.swift */,\n",
    )
    text = text[:group_start] + group_block + text[group_end:]

    resources_group = "CC15490F2C4B84DD00A4173E /* Resources */ = {"
    resources_start = text.find(resources_group)
    resources_end = text.find("/* End PBXGroup section */", resources_start)
    resources_block = text[resources_start:resources_end]
    resources_block = insert_after_once(
        resources_block,
        "\t\t\tchildren = (\n",
        f"\t\t\t\t{payload_ref} /* DeviceMatrixPayload.dylib */,\n",
    )
    text = text[:resources_start] + resources_block + text[resources_end:]

    project.write_text(text, encoding="utf-8", newline="\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--payload", type=Path, required=True)
    parser.add_argument("--service", type=Path, required=True)
    args = parser.parse_args()
    patch_project(args.root.resolve(), args.payload.resolve(), args.service.resolve())
    print(f"[OK] patched {args.root}")


if __name__ == "__main__":
    main()
