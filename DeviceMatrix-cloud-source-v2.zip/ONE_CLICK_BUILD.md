# One-click build variant

`build-macos-one-click.sh` uses the vendored TrollFools injection engine and adds a context-menu action to every eligible target application.

The action calls the existing injector with `DeviceMatrixPayload.dylib`, requests persistence, and refreshes the application status. The payload derives its stable synthetic profile from the target Bundle ID, so the same target keeps the same profile while different targets receive different profiles.

Build on macOS:

```sh
./build-macos-one-click.sh
```

The vendored source is kept under `vendor/TrollFools` and remains a separate upstream checkout. `patch_vendor.py` operates only on the disposable copy under `build-one-click`.

The upstream project documents its injection engine as compatible with the TrollStore-supported iOS range and includes rollback/eject handling. Exact iOS 18 availability still depends on the device's TrollStore Lite/jailbreak path.
