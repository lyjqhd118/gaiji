# 云端构建说明

## 触发方式

GitHub Actions 文件位于 `.github/workflows/build-ipa.yml`。推送到 `main` 或在 Actions 页面手动运行 `Build DeviceMatrix IPA`，构建机会在 macOS runner 上安装 XcodeGen 与 ldid，然后运行 `build-macos-one-click.sh`。

## 产物

成功后在 Actions 的 Artifacts 下载：

- `DeviceMatrix-one-click-ipa/DeviceMatrix-one-click.ipa`
- `DeviceMatrix-build-evidence/`：构建目录与验证证据

## 前置条件

1. 将本目录放入一个 GitHub 仓库。
2. 使用 macOS runner；本项目需要 Apple SDK 与 Xcode 工具链。
3. 在目标设备侧使用 TrollStore 安装生成的 IPA，并按 App 列表选择目标应用。

本工作区已生成工作流，但当前尚未绑定 GitHub 仓库或账号连接，因此还没有云端运行记录和下载链接。
