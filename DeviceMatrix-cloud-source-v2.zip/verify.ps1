$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$required = @(
  'README.md', 'project.yml', 'build-macos.sh', 'rollback.ps1',
  'Sources/DeviceMatrixApp/Info.plist',
  'Sources/DeviceMatrixApp/DeviceMatrix.entitlements',
  'Sources/DeviceMatrixApp/DeviceMatrixApp.swift',
  'Sources/DeviceMatrixPayload/DeviceMatrixPayload.m',
  'Integration/DeviceMatrixService.swift',
  'patch_vendor.py',
  'build-macos-one-click.sh',
  'ONE_CLICK_BUILD.md',
  'Resources/README.txt'
)
$missing = @($required | Where-Object { -not (Test-Path (Join-Path $root $_)) })
if ($missing.Count -gt 0) { throw "Missing files: $($missing -join ', ')" }

[xml](Get-Content (Join-Path $root 'Sources/DeviceMatrixApp/Info.plist')) | Out-Null
[xml](Get-Content (Join-Path $root 'Sources/DeviceMatrixApp/DeviceMatrix.entitlements')) | Out-Null

$swift = Get-Content -Raw (Join-Path $root 'Sources/DeviceMatrixApp/DeviceMatrixApp.swift')
$objc = Get-Content -Raw (Join-Path $root 'Sources/DeviceMatrixPayload/DeviceMatrixPayload.m')
$service = Get-Content -Raw (Join-Path $root 'Integration/DeviceMatrixService.swift')
foreach ($needle in @('LSApplicationWorkspace','exportPayload','UIActivityViewController','identifierForVendor','advertisingIdentifier','InjectorV3','shouldPersist','DeviceMatrixService')) {
  if ($swift -notmatch [regex]::Escape($needle) -and $objc -notmatch [regex]::Escape($needle) -and $service -notmatch [regex]::Escape($needle)) { throw "Missing feature marker: $needle" }
}

$result = [ordered]@{
  timestamp = (Get-Date).ToString('o')
  workspace = $root
  filesChecked = $required.Count
  sourceLineCounts = [ordered]@{
    swift = ($swift -split "`n").Count
    objc = ($objc -split "`n").Count
    service = ($service -split "`n").Count
  }
  xcodebuild = [bool](Get-Command xcodebuild -ErrorAction SilentlyContinue)
  xcodegen = [bool](Get-Command xcodegen -ErrorAction SilentlyContinue)
  ldid = [bool](Get-Command ldid -ErrorAction SilentlyContinue)
  ipaPresent = Test-Path (Join-Path $root 'dist/DeviceMatrix.ipa')
}
$result | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $root 'verification.json') -Encoding UTF8
$result | ConvertTo-Json -Depth 4
exit 0
