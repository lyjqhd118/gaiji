XcodeGen 修正记录

基线文件：project.yml.pre-xcodegen-fix
基线 SHA256：ADD7891E0FEA15D596BB655688DD1E415F4A657D3980BB64D3FACFE04E1FB96F
变更：DeviceMatrixPayload.type: dynamic-library -> library.dynamic
原因：XcodeGen Project Spec 使用 library.dynamic 作为动态库产品类型。
