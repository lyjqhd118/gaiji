DeviceMatrixPayload.dylib is copied into the app bundle by build-macos.sh.
The payload derives a stable synthetic profile from the target app's bundle identifier.
