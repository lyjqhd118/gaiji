#import <UIKit/UIKit.h>
#import <AdSupport/AdSupport.h>
#import <CommonCrypto/CommonDigest.h>
#import <objc/runtime.h>

static NSString *DMSeed(void) {
    NSString *bundleID = [[NSBundle mainBundle] bundleIdentifier] ?: @"unknown.target";
    return [NSString stringWithFormat:@"DeviceMatrix:%@", bundleID];
}

static NSString *DMUUID(void) {
    NSData *input = [DMSeed() dataUsingEncoding:NSUTF8StringEncoding];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(input.bytes, (CC_LONG)input.length, digest);
    digest[6] = (digest[6] & 0x0f) | 0x40;
    digest[8] = (digest[8] & 0x3f) | 0x80;
    NSMutableString *value = [NSMutableString stringWithCapacity:36];
    for (NSUInteger i = 0; i < 16; i++) {
        if (i == 4 || i == 6 || i == 8 || i == 10) [value appendString:@"-"];
        [value appendFormat:@"%02x", digest[i]];
    }
    return value;
}

static NSUUID *DMVendorUUID(void) {
    return [[NSUUID alloc] initWithUUIDString:DMUUID()];
}

static NSUUID *DMAdvertisingUUID(void) {
    NSString *seed = [DMSeed() stringByAppendingString:@":advertising"];
    NSData *input = [seed dataUsingEncoding:NSUTF8StringEncoding];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(input.bytes, (CC_LONG)input.length, digest);
    digest[6] = (digest[6] & 0x0f) | 0x40;
    digest[8] = (digest[8] & 0x3f) | 0x80;
    NSMutableString *value = [NSMutableString stringWithCapacity:36];
    for (NSUInteger i = 0; i < 16; i++) {
        if (i == 4 || i == 6 || i == 8 || i == 10) [value appendString:@"-"];
        [value appendFormat:@"%02x", digest[i]];
    }
    return [[NSUUID alloc] initWithUUIDString:value];
}

@interface UIDevice (DeviceMatrix)
@end

@implementation UIDevice (DeviceMatrix)

- (NSUUID *)dm_identifierForVendor {
    return DMVendorUUID();
}

- (NSString *)dm_name {
    return @"DeviceMatrix Device";
}

- (NSString *)dm_model {
    return @"iPhone17,1";
}

- (NSString *)dm_localizedModel {
    return @"iPhone";
}

- (NSString *)dm_systemName {
    return @"iOS";
}

- (NSString *)dm_systemVersion {
    return @"18.0";
}

@end

@interface ASIdentifierManager (DeviceMatrix)
@end

@implementation ASIdentifierManager (DeviceMatrix)

- (NSUUID *)dm_advertisingIdentifier {
    return DMAdvertisingUUID();
}

@end

static void DMSwizzle(Class cls, SEL original, SEL replacement) {
    Method source = class_getInstanceMethod(cls, original);
    Method target = class_getInstanceMethod(cls, replacement);
    if (!source || !target) return;
    method_exchangeImplementations(source, target);
}

__attribute__((constructor))
static void DMInstallHooks(void) {
    @autoreleasepool {
        DMSwizzle(UIDevice.class, @selector(identifierForVendor), @selector(dm_identifierForVendor));
        DMSwizzle(UIDevice.class, @selector(name), @selector(dm_name));
        DMSwizzle(UIDevice.class, @selector(model), @selector(dm_model));
        DMSwizzle(UIDevice.class, @selector(localizedModel), @selector(dm_localizedModel));
        DMSwizzle(UIDevice.class, @selector(systemName), @selector(dm_systemName));
        DMSwizzle(UIDevice.class, @selector(systemVersion), @selector(dm_systemVersion));
        DMSwizzle(ASIdentifierManager.class, @selector(advertisingIdentifier), @selector(dm_advertisingIdentifier));
    }
}
