import SwiftUI
import UIKit

struct DeviceProfile: Codable, Identifiable, Equatable {
    var id: UUID = UUID()
    var bundleID: String
    var displayName: String
    var generatedAt: Date
    var enabled: Bool = true
}

struct TargetApp: Identifiable, Hashable {
    let id: String
    let name: String
    var bundleID: String { id }
}

@main
struct DeviceMatrixApp: App {
    @StateObject private var store = ProfileStore()

    var body: some Scene {
        WindowGroup {
            ContentView(store: store)
        }
    }
}

final class ProfileStore: ObservableObject {
    @Published var targets: [TargetApp] = []
    @Published var selected: TargetApp?
    @Published var profiles: [String: DeviceProfile] = [:]
    @Published var message = "准备就绪"

    private let fileName = "profiles.json"

    init() {
        loadProfiles()
        refreshApps()
    }

    func refreshApps() {
        targets = InstalledAppProvider.list()
        if selected == nil { selected = targets.first }
        message = "已发现 \(targets.count) 个应用"
    }

    func profile(for target: TargetApp) -> DeviceProfile {
        if let current = profiles[target.bundleID] { return current }
        return DeviceProfile(bundleID: target.bundleID,
                             displayName: target.name,
                             generatedAt: Date())
    }

    func saveProfile(for target: TargetApp) {
        profiles[target.bundleID] = profile(for: target)
        persistProfiles()
        message = "已保存 \(target.name) 的应用级配置"
    }

    func exportPayload(for target: TargetApp) {
        saveProfile(for: target)
        guard let dylib = Bundle.main.url(forResource: "DeviceMatrixPayload", withExtension: "dylib") else {
            message = "未找到载荷；请用构建脚本重新打包"
            return
        }
        let fm = FileManager.default
        let dir = fm.temporaryDirectory.appendingPathComponent("DeviceMatrix-\(target.bundleID)", isDirectory: true)
        try? fm.removeItem(at: dir)
        do {
            try fm.createDirectory(at: dir, withIntermediateDirectories: true)
            let payloadURL = dir.appendingPathComponent("DeviceMatrixPayload.dylib")
            try fm.copyItem(at: dylib, to: payloadURL)
            let note = """
            DeviceMatrix injection package
            Target: \(target.name)
            Bundle ID: \(target.bundleID)
            Scope: target process only
            Action: in TrollFools, select the same target and inject DeviceMatrixPayload.dylib.
            Then fully terminate and relaunch the target app.
            """
            try note.data(using: .utf8)?.write(to: dir.appendingPathComponent("TARGET.txt"))
            presentShare(items: [payloadURL, dir.appendingPathComponent("TARGET.txt")])
            message = "已生成 \(target.name) 的注入载荷"
        } catch {
            message = "导出失败：\(error.localizedDescription)"
        }
    }

    private func loadProfiles() {
        guard let url = documentsURL() else { return }
        guard let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode([String: DeviceProfile].self, from: data) else { return }
        profiles = decoded
    }

    private func persistProfiles() {
        guard let url = documentsURL(), let data = try? JSONEncoder().encode(profiles) else { return }
        try? data.write(to: url, options: .atomic)
    }

    private func documentsURL() -> URL? {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent(fileName)
    }

    private func presentShare(items: [Any]) {
        DispatchQueue.main.async {
            guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let root = scene.windows.first?.rootViewController else { return }
            let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
            root.present(controller, animated: true)
        }
    }
}

struct ContentView: View {
    @ObservedObject var store: ProfileStore

    var body: some View {
        NavigationStack {
            VStack(spacing: 14) {
                HStack {
                    Text("DeviceMatrix").font(.title2.bold())
                    Spacer()
                    Button("刷新") { store.refreshApps() }
                }

                Text("选择一个应用，导出只作用于该应用进程的注入载荷")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                List(store.targets) { target in
                    Button {
                        store.selected = target
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(target.name).foregroundStyle(.primary)
                                Text(target.bundleID).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if store.selected == target { Image(systemName: "checkmark.circle.fill") }
                        }
                    }
                }
                .listStyle(.plain)

                if let selected = store.selected {
                    VStack(spacing: 10) {
                        Text("目标：\(selected.name)").font(.headline)
                        Text("Bundle ID：\(selected.bundleID)").font(.caption).foregroundStyle(.secondary)
                        Button("导出注入载荷") { store.exportPayload(for: selected) }
                            .buttonStyle(.borderedProminent)
                    }
                    .padding(.bottom, 6)
                }

                Text(store.message).font(.caption).foregroundStyle(.secondary)
            }
            .padding()
            .navigationTitle("按应用生效")
        }
    }
}

enum InstalledAppProvider {
    static func list() -> [TargetApp] {
        guard let workspaceClass = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type,
              let workspace = workspaceClass.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as AnyObject?,
              let raw = workspace.perform(NSSelectorFromString("allInstalledApplications"))?.takeUnretainedValue() as? [AnyObject] else {
            return []
        }

        let result = raw.compactMap { item -> TargetApp? in
            let bundleID = (item.value(forKey: "applicationIdentifier") as? String)
                ?? (item.value(forKey: "bundleIdentifier") as? String)
            guard let bundleID, !bundleID.isEmpty else { return nil }
            let name = (item.value(forKey: "localizedName") as? String) ?? bundleID
            return TargetApp(id: bundleID, name: name)
        }
        return Array(Set(result)).sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }
}
