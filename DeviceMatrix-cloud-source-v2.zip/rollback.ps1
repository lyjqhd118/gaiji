$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
foreach ($path in @('build', 'dist', 'DeviceMatrix.xcodeproj', 'verification.json')) {
  $full = Join-Path $root $path
  if (Test-Path $full) {
    $resolved = (Resolve-Path -LiteralPath $full).Path
    $rootResolved = (Resolve-Path -LiteralPath $root).Path.TrimEnd('\')
    if ($resolved -eq $rootResolved -or -not $resolved.StartsWith($rootResolved + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
      throw "Refusing to remove path outside workspace: $resolved"
    }
    Remove-Item -LiteralPath $resolved -Recurse -Force
  }
}
Write-Output "[OK] build outputs removed; source files preserved: $root"
exit 0
