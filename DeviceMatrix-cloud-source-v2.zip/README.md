# DeviceMatrix — 按目标应用生效的设备信息配置工程

这是一个面向 TrollStore 安装链的 iOS 工程，包含独立导出模式与一键注入模式：

- `DeviceMatrix`：选择已安装应用、生成稳定的应用级配置、导出注入载荷。
- `DeviceMatrixPayload.dylib`：只在被注入的目标进程内生效，按目标 Bundle ID 生成稳定的合成设备资料。
- `build-macos.sh`：在 macOS + Xcode 上编译、签名并打包 IPA。
- `build-macos-one-click.sh`：把载荷接入 vendored TrollFools，生成“选中目标应用后直接注入”的 IPA。
- `verify.ps1`：Windows 侧静态完整性检查。
- `rollback.ps1`：删除本工程生成的构建输出，不触碰源代码。

## 当前边界

独立 IPA 运行在自己的沙盒进程中，按目标应用生效需要注入目标应用。`build-macos-one-click.sh` 已把注入动作接入 vendored TrollFools；`build-macos.sh` 仍保留为轻量导出模式。

载荷当前覆盖：

- `UIDevice.identifierForVendor`
- `UIDevice.name`
- `UIDevice.model`
- `UIDevice.localizedModel`
- `UIDevice.systemName`
- `UIDevice.systemVersion`
- `ASIdentifierManager.advertisingIdentifier`

这不是系统级真实硬件字段修改；序列号、Wi‑Fi/Bluetooth 地址、Secure Enclave 标识等字段不在此载荷范围。

## 构建

在 macOS 上安装 Xcode、XcodeGen 与 ldid 后执行：

```sh
./build-macos.sh
```

产物：`dist/DeviceMatrix.ipa`。设备架构为 `arm64`，最低部署版本为 iOS 15.0。

一键注入产物：

```sh
./build-macos-one-click.sh
```

产物：`dist-one-click/DeviceMatrix-one-click.ipa`。

## 使用链路

1. 用 TrollStore 安装 `DeviceMatrix.ipa`。
2. 打开应用，刷新已安装应用列表并选择目标应用。
3. 点击“导出注入载荷”，得到 `DeviceMatrixPayload.dylib` 与目标说明。
4. 在 TrollFools 中选中同一个目标应用，注入 `DeviceMatrixPayload.dylib`。
5. 完全退出并重新打开目标应用；载荷只在该目标进程中运行。

## 兼容性

- 工程最低部署版本：iOS 15.0。
- TrollStore 的可安装范围取决于设备、系统小版本与当前安装链；iOS 18 不作为“裸 TrollStore 全覆盖”承诺。
- iOS 18 设备需使用当时可用的 TrollStore Lite/越狱注入路径，或其他兼容的应用内注入器。
- 目标应用若启用强完整性校验、加密主二进制或多进程架构，需按目标版本单独验证。

## 目录

```text
Sources/DeviceMatrixApp/       宿主应用 SwiftUI 源码
Sources/DeviceMatrixPayload/   注入载荷 Objective-C 源码
Resources/                     资源与配置说明
project.yml                    XcodeGen 工程描述
build-macos.sh                 macOS 构建脚本
verify.ps1                     Windows 静态验证
rollback.ps1                   构建输出回滚
```
