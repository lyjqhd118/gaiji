import CocoaLumberjackSwift
import Foundation

enum DeviceMatrixService {
    static func apply(to app: App) {
        guard let payload = Bundle.main.url(forResource: "DeviceMatrixPayload", withExtension: "dylib") else {
            DDLogError("DeviceMatrixPayload.dylib is missing", ddlog: InjectorV3.main.logger)
            return
        }

        do {
            let injector = try InjectorV3(app.url)
            try injector.inject([payload], shouldPersist: true)
            app.reload()
            DDLogInfo("DeviceMatrix applied to \(app.bid)", ddlog: InjectorV3.main.logger)
        } catch {
            DDLogError("DeviceMatrix failed for \(app.bid): \(error)", ddlog: InjectorV3.main.logger)
        }
    }
}
