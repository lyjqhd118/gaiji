import hashlib, json, os, zipfile
from pathlib import Path
root = Path.cwd()
out = root / 'DeviceMatrix-cloud-source.zip'
if out.exists():
    out.unlink()
excluded = {'DeviceMatrix-cloud-source.zip', 'build-test-patched-20261015'}
items = [p for p in root.iterdir() if p.name not in excluded and not (p.is_dir() and (p.name.startswith('build') or p.name.startswith('dist')))]
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in items:
        if p.is_dir():
            for f in p.rglob('*'):
                if f.is_file() and '.git' not in f.parts:
                    z.write(f, f.relative_to(root).as_posix())
        elif p.is_file():
            z.write(p, p.relative_to(root).as_posix())
h = hashlib.sha256(out.read_bytes()).hexdigest()
with zipfile.ZipFile(out) as z:
    names = z.namelist()
required = [
    '.github/workflows/build-ipa.yml',
    'build-macos-one-click.sh',
    'project.yml',
    'Sources/DeviceMatrixPayload/DeviceMatrixPayload.m',
    'Integration/DeviceMatrixService.swift',
]
checks = [{'path': x, 'present': x in names or (x + '/') in names or any(n.startswith(x.rstrip('/') + '/') for n in names)} for x in required]
result = {'archive': str(out), 'sha256': h, 'bytes': out.stat().st_size, 'entries': len(names), 'required': checks, 'missing': sum(not x['present'] for x in checks)}
(root / 'cloud-package-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
with (root / 'verification.log').open('a', encoding='utf-8') as f:
    f.write(f"[{__import__('datetime').datetime.now().astimezone().isoformat()}] cloud-source-package: path={out} sha256={h} size={out.stat().st_size} exit=0\n")
print(json.dumps(result, ensure_ascii=False, indent=2))

