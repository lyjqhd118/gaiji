#!/bin/sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
BUILD="$ROOT/build-one-click"
DIST="$ROOT/dist-one-click"
VENDOR="$ROOT/vendor/TrollFools"

command -v xcodebuild >/dev/null 2>&1 || { echo "xcodebuild is required" >&2; exit 2; }
command -v xcodegen >/dev/null 2>&1 || { echo "xcodegen is required" >&2; exit 2; }
command -v python3 >/dev/null 2>&1 || { echo "python3 is required" >&2; exit 2; }
command -v ldid >/dev/null 2>&1 || { echo "ldid is required for TrollStore signing" >&2; exit 2; }

rm -rf "$BUILD" "$DIST"
mkdir -p "$BUILD" "$DIST/Payload"
cp -R "$VENDOR" "$BUILD/TrollFoolsDeviceMatrix"

xcodegen generate --spec "$ROOT/project.yml" --project "$ROOT/DeviceMatrix.xcodeproj"
xcodebuild -project "$ROOT/DeviceMatrix.xcodeproj" -scheme DeviceMatrixPayload \
  -configuration Release -sdk iphoneos -derivedDataPath "$BUILD/payload-derived" \
  CODE_SIGNING_ALLOWED=NO build

PAYLOAD=$(find "$BUILD/payload-derived/Build/Products" -name 'DeviceMatrixPayload.dylib' -type f | head -n 1)
test -n "$PAYLOAD"

python3 "$ROOT/patch_vendor.py" \
  --root "$BUILD/TrollFoolsDeviceMatrix" \
  --payload "$PAYLOAD" \
  --service "$ROOT/Integration/DeviceMatrixService.swift"

xcodebuild -project "$BUILD/TrollFoolsDeviceMatrix/TrollFools.xcodeproj" -scheme TrollFools \
  -configuration Release -sdk iphoneos -derivedDataPath "$BUILD/app-derived" \
  CODE_SIGNING_ALLOWED=NO build

APP=$(find "$BUILD/app-derived/Build/Products" -path '*/Release-iphoneos/TrollFools.app' -type d | head -n 1)
test -n "$APP"
ldid -S"$BUILD/TrollFoolsDeviceMatrix/TrollFools/TrollFools.entitlements" "$APP/TrollFools"
ldid -S "$APP/DeviceMatrixPayload.dylib"
cp -R "$APP" "$DIST/Payload/DeviceMatrix.app"
(cd "$DIST" && /usr/bin/zip -qry DeviceMatrix-one-click.ipa Payload)
echo "[OK] $DIST/DeviceMatrix-one-click.ipa"
